export default [
  'frontend',
  'backend'
]
